RICA WATER TRACKER — ANDROID APK BUILD

This is the Android-ready project source. The APK is created by GitHub Actions (the current workspace does not have the Android SDK needed to compile an APK locally).

BUILD YOUR APK (FREE)
1. Sign in to https://github.com/ and create a new repository (Private is okay).
2. Upload the CONTENTS of this folder to the repository root. Make sure the .github/workflows/build-apk.yml file is included. If uploading through the website, enable showing hidden files or upload the .github folder too.
3. Open the repository's Actions tab and choose the “Build APK” workflow. Click “Run workflow” if it hasn't started automatically after uploading files.
4. Wait for the run to finish successfully, open the completed run, and find the “Rica-Water-Tracker-APK” artifact near the bottom.
5. Download and unzip that artifact. The app-debug.apk inside is the installable Android app.
6. Send app-debug.apk to your Android phone, open it, and allow “Install unknown apps” if Android asks.

NOTES
- This workflow creates a debug APK for personal/testing use; it is not a Play Store release-signed APK.
- Keep the repository private if you do not want the source code public.
- App ID: com.rica.watertracker
